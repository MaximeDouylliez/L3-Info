package ressource;

public class RessourceInvalidException {

}
