package ressource;

public class Cabine implements Ressource {

	public String description() {
		return "Cabine";
	}
}
