package ressource;

public interface Ressource {

}
