package ressource;

public class Panier implements Ressource {

	
	public String description() {
		return "Panier";
	}

}
