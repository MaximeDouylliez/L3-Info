package piscine;

public enum EtatAction {NON_TERMINE,TERMINE};