package piscine;

@SuppressWarnings("serial")
public class ActionTermineException extends Exception{


}
