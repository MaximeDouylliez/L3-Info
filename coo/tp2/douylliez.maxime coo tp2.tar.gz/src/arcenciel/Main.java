package arcenciel;

public static void Main{
private Arcenciel robin;

public void Main(char* couleur){

if(couleur )
{
robin = new Arcenciel(




}

}
