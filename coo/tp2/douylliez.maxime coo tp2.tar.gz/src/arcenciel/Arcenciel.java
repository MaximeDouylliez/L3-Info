
package arcenciel;
public enum Arcenciel{ROUGE, ORANGE, JAUNE, VERT, BLEU, INDIGO,VIOLET}

