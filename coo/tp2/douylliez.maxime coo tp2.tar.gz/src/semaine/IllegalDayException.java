package Semaine;

import java.*;

public class IllegalDayException extends Exception
{

public IllegalDayException(String s)
{
this.super(s);
}
}
